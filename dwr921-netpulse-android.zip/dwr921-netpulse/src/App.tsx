import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Capacitor } from '@capacitor/core'
import { Browser } from '@capacitor/browser'
import {
  Activity, AlertTriangle, ArrowUpRight, CheckCircle2, Clock3, Gauge,
  Globe2, LayoutDashboard, Pause, Play, RefreshCw, Router, ShieldCheck,
  Signal, Timer, Wifi, XCircle, Zap,
} from 'lucide-react'

type Tab = 'home' | 'diagnostics' | 'stability' | 'router'
type Probe = { name: string; ok: boolean; ms: number | null; detail: string }
type Sample = { id: number; at: number; ok: boolean; ms: number | null }

const ROUTER_URL = 'http://192.168.0.1/admin/index.html#/usbmodem/basic?modem=1'
const ENDPOINTS = [
  { name: 'Cloudflare DNS', url: 'https://cloudflare-dns.com/dns-query?name=example.com&type=A', headers: { Accept: 'application/dns-json' } },
  { name: 'Google DNS', url: 'https://dns.google/resolve?name=example.com&type=A', headers: {} },
]

async function probeEndpoint(endpoint: typeof ENDPOINTS[number]): Promise<Probe> {
  const controller = new AbortController()
  const timeout = window.setTimeout(() => controller.abort(), 5000)
  const started = performance.now()
  try {
    const response = await fetch(endpoint.url + '&_np=' + Date.now(), {
      headers: endpoint.headers, cache: 'no-store', signal: controller.signal,
    })
    const ms = Math.round(performance.now() - started)
    if (!response.ok) return { name: endpoint.name, ok: false, ms, detail: 'HTTP ' + response.status }
    await response.text()
    return { name: endpoint.name, ok: true, ms: Math.round(performance.now() - started), detail: 'الاستجابة وصلت' }
  } catch (error) {
    const detail = error instanceof DOMException && error.name === 'AbortError' ? 'انتهت مهلة الطلب' : 'تعذر الوصول إلى الخادم'
    return { name: endpoint.name, ok: false, ms: null, detail }
  } finally {
    window.clearTimeout(timeout)
  }
}

function timeLabel(ms: number | null) {
  return ms === null ? '—' : ms + ' ms'
}

function clockLabel(time: number) {
  return new Date(time).toLocaleTimeString('ar-PS', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
}

export default function App() {
  const [tab, setTab] = useState<Tab>('home')
  const [busy, setBusy] = useState(false)
  const [monitoring, setMonitoring] = useState(false)
  const [stabilityTest, setStabilityTest] = useState(false)
  const [results, setResults] = useState<Probe[] | null>(null)
  const [samples, setSamples] = useState<Sample[]>([])
  const [notice, setNotice] = useState('اضغط «فحص الآن» لقياس الاستجابة عبر الإنترنت.')
  const busyRef = useRef(false)
  const stabilityRef = useRef<number | null>(null)

  const runTest = useCallback(async (silent = false) => {
    if (busyRef.current) return
    busyRef.current = true
    setBusy(true)
    try {
      const next = await Promise.all(ENDPOINTS.map(probeEndpoint))
      setResults(next)
      const succeeded = next.filter((item) => item.ok)
      const ms = succeeded.length ? Math.round(succeeded.reduce((sum, item) => sum + (item.ms || 0), 0) / succeeded.length) : null
      const ok = succeeded.length > 0
      setSamples((old) => [{ id: Date.now(), at: Date.now(), ok, ms }, ...old].slice(0, 30))
      if (!silent) setNotice(ok ? 'نجح فحص واحد على الأقل. هذه أزمنة طلبات HTTPS وليست Ping مباشرًا.' : 'فشل الوصول إلى خادمي الفحص؛ افحص اتصال الإنترنت من الهاتف.')
    } catch {
      if (!silent) setNotice('حدث خطأ أثناء الفحص. حاول مرة أخرى.')
    } finally {
      busyRef.current = false
      setBusy(false)
    }
  }, [])

  useEffect(() => {
    if (!monitoring) return
    const timer = window.setInterval(() => {
      if (stabilityRef.current && Date.now() >= stabilityRef.current) {
        stabilityRef.current = null
        setStabilityTest(false)
        setMonitoring(false)
        setNotice('انتهى اختبار الاستقرار لمدة دقيقة. راجع سجل العينات.')
        return
      }
      void runTest(true)
    }, 8000)
    return () => window.clearInterval(timer)
  }, [monitoring, runTest])

  useEffect(() => {
    if (!stabilityTest) return
    const timer = window.setTimeout(() => {
      stabilityRef.current = null
      setStabilityTest(false)
      setMonitoring(false)
      setNotice('انتهى اختبار الاستقرار لمدة دقيقة. راجع سجل العينات.')
    }, 60000)
    return () => window.clearTimeout(timer)
  }, [stabilityTest])

  const successRate = useMemo(() => samples.length ? Math.round(samples.filter((item) => item.ok).length / samples.length * 100) : null, [samples])
  const avgMs = useMemo(() => {
    const values = samples.filter((sample) => sample.ms !== null).map((sample) => sample.ms as number)
    return values.length ? Math.round(values.reduce((sum, item) => sum + item, 0) / values.length) : null
  }, [samples])

  const openRouter = async () => {
    try {
      if (Capacitor.isNativePlatform()) {
        await Browser.open({ url: ROUTER_URL, toolbarColor: '#091321' })
      } else {
        window.open(ROUTER_URL, '_blank', 'noopener,noreferrer')
      }
    } catch {
      setNotice('تعذر فتح صفحة الراوتر. تأكد من اتصال الهاتف بشبكة Wi-Fi الخاصة بالراوتر.')
    }
  }

  const startStability = () => {
    stabilityRef.current = Date.now() + 60000
    setStabilityTest(true)
    setMonitoring(true)
    setNotice('بدأ اختبار الاستقرار لمدة 60 ثانية، بمعدل فحص كل 8 ثوانٍ تقريبًا.')
    void runTest(false)
  }

  const nav = [
    { id: 'home' as const, label: 'الرئيسية', icon: LayoutDashboard },
    { id: 'diagnostics' as const, label: 'التشخيص', icon: Activity },
    { id: 'stability' as const, label: 'الاستقرار', icon: ShieldCheck },
    { id: 'router' as const, label: 'الراوتر', icon: Router },
  ]

  return <main className="app-shell">
    <header className="topbar">
      <div className="brand"><div className="brand-icon"><Activity size={23} /></div><div><h1>NetPulse<span>.</span></h1><p>مراقبة استقرار الشبكة</p></div></div>
      <div className="live-chip"><i />{monitoring ? 'مراقبة نشطة' : 'جاهز للفحص'}</div>
    </header>

    <section className="device-card">
      <div className="device-symbol"><Router size={24} /></div>
      <div className="device-text"><span>الجهاز المتصل</span><strong>D-Link DWR-921</strong><small>شريحة خلوية · اتصال 3G حسب وصفك</small></div>
      <Signal className="signal-icon" size={23} />
    </section>

    {tab === 'home' && <>
      <section className="hero-card">
        <div className="hero-orb"><Wifi size={33} /></div>
        <span className="eyebrow">فحص الاتصال</span>
        <h2>{results ? (results.some((item) => item.ok) ? 'الاتصال يستجيب' : 'تعذر الوصول') : 'خلّينا نفحص الشبكة'}</h2>
        <p>نختبر الوصول إلى خادمي DNS عبر HTTPS ونراقب تغيّر الاستجابة.</p>
        <button className="primary-button" onClick={() => void runTest(false)} disabled={busy}>
          {busy ? <RefreshCw className="spin" size={19} /> : <Zap size={19} />}{busy ? 'جارٍ الفحص…' : 'فحص الآن'}
        </button>
        <div className="hero-foot"><span><ShieldCheck size={14} /> لا نحفظ كلمة مرور الراوتر</span><span>{samples.length} عينة</span></div>
      </section>
      <section className="stats-grid">
        <div className="stat-card"><div className="stat-top"><Gauge size={18}/><span>متوسط الاستجابة</span></div><strong>{timeLabel(avgMs)}</strong><small>للطلبات الناجحة</small></div>
        <div className="stat-card"><div className="stat-top"><CheckCircle2 size={18}/><span>نجاح العينات</span></div><strong>{successRate === null ? '—' : successRate + '%'}</strong><small>من {samples.length} عينة</small></div>
      </section>
      <section className="section-card"><div className="section-title"><h3>آخر نتيجة</h3><button className="text-button" onClick={() => setTab('diagnostics')}>التفاصيل <ArrowUpRight size={14}/></button></div>
        {!results && <div className="empty-state">لم يبدأ الفحص بعد.</div>}
        {results?.map((item) => <div className="result-row" key={item.name}><span className={'result-icon ' + (item.ok ? 'good' : 'bad')}>{item.ok ? <CheckCircle2 size={17}/> : <XCircle size={17}/>}</span><div className="result-copy"><strong>{item.name}</strong><small>{item.detail}</small></div><b>{timeLabel(item.ms)}</b></div>)}
      </section>
    </>}

    {tab === 'diagnostics' && <section className="section-card page-card"><div className="page-heading"><span className="page-icon"><Activity size={22}/></span><div><h2>تشخيص الاتصال</h2><p>اختبارات وصول فعلية من الهاتف</p></div></div>
      <button className="primary-button full-button" onClick={() => void runTest(false)} disabled={busy}>{busy ? <RefreshCw className="spin" size={18}/> : <Play size={18}/>}إجراء الفحص</button>
      {results?.map((item) => <div className="result-row" key={item.name}><span className={'result-icon ' + (item.ok ? 'good' : 'bad')}>{item.ok ? <CheckCircle2 size={17}/> : <XCircle size={17}/>}</span><div className="result-copy"><strong>{item.name}</strong><small>{item.detail}</small></div><b>{timeLabel(item.ms)}</b></div>)}
      <div className="info-note"><AlertTriangle size={17}/><span>هذه القياسات زمن طلب HTTPS إلى DNS عام؛ ليست قياس Ping ICMP ولا قوة إشارة المودم.</span></div>
    </section>}

    {tab === 'stability' && <section className="section-card page-card"><div className="page-heading"><span className="page-icon"><ShieldCheck size={22}/></span><div><h2>اختبار الاستقرار</h2><p>مراقبة قصيرة لاكتشاف الفشل المتكرر</p></div></div>
      <div className="stability-meter"><Timer size={25}/><strong>{stabilityTest ? '60 ثانية' : 'اختبار لمدة دقيقة'}</strong><span>{monitoring ? 'الفحص الدوري يعمل تقريبًا كل 8 ثوانٍ' : 'لم يبدأ الاختبار'}</span></div>
      {!monitoring ? <button className="primary-button full-button" onClick={startStability}><Play size={18}/>ابدأ اختبار الاستقرار</button> : <button className="secondary-button full-button" onClick={() => { stabilityRef.current = null; setStabilityTest(false); setMonitoring(false); setNotice('تم إيقاف المراقبة.'); }}><Pause size={18}/>إيقاف المراقبة</button>}
      <div className="section-title"><h3>سجل العينات</h3><span className="sample-count">{samples.length} عينة</span></div>
      {samples.length === 0 ? <div className="empty-state">ستظهر النتائج بعد بدء الاختبار.</div> : samples.slice(0, 10).map((sample) => <div className="history-row" key={sample.id}><span className={'history-dot ' + (sample.ok ? 'good' : 'bad')}/><span>{clockLabel(sample.at)}</span><b>{sample.ok ? timeLabel(sample.ms) : 'فشل'}</b></div>)}
    </section>}

    {tab === 'router' && <section className="section-card page-card"><div className="page-heading"><span className="page-icon"><Router size={22}/></span><div><h2>إعدادات الراوتر</h2><p>D-Link DWR-921 · اتصال 3G</p></div></div>
      <button className="primary-button full-button" onClick={() => void openRouter()}><ArrowUpRight size={18}/>فتح صفحة الراوتر</button>
      <div className="router-address">192.168.0.1 <Globe2 size={16}/></div>
      <div className="tip-card"><h3><ShieldCheck size={18}/> افحص هذه الإعدادات</h3><p><b>DNS Check:</b> إن كان موجودًا، راجع تفعيله وفترة الفحص وفق دليل إصدار جهازك.</p><p><b>Keep Alive / Use Ping:</b> راجع الخيارات المتاحة في نسخة البرنامج الثابت لديك.</p><p><b>APN:</b> تأكد من مطابقته لإعدادات شركة الشريحة.</p></div>
      <div className="info-note"><AlertTriangle size={17}/><span>التطبيق لا يغيّر الإعدادات ولا يعيد تشغيل المودم تلقائيًا. لا تغيّر كلمات المرور أو إعدادات الشبكة قبل معرفة أثرها.</span></div>
    </section>}

    <div className="notice"><Clock3 size={16}/><span>{notice}</span></div>
    <footer className="bottom-nav">{nav.map(({ id, label, icon: Icon }) => <button key={id} className={tab === id ? 'nav-button active' : 'nav-button'} onClick={() => setTab(id)}><Icon size={20}/><span>{label}</span></button>)}</footer>
  </main>
}

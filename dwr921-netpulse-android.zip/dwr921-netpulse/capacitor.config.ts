import type { CapacitorConfig } from '@capacitor/cli'

const config: CapacitorConfig = {
  appId: 'com.netpulse.dwr921',
  appName: 'NetPulse',
  webDir: 'dist',
  server: { androidScheme: 'https' },
}

export default config

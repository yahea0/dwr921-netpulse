# NetPulse — Android APK for D-Link DWR-921

تطبيق Android عربي RTL مبني باستخدام React + TypeScript + Capacitor، لمراقبة وصول الإنترنت وتشخيص الانقطاع المتكرر مع راوتر D-Link DWR-921 وشريحة 3G.

## رابط تنزيل APK بعد أول بناء ناجح

`https://github.com/yahea0/dwr921-netpulse/releases/latest/download/NetPulse.apk`

هذا الرابط يعمل بعد نجاح أول تشغيل لسير GitHub Actions؛ ملف APK لا يكون موجودًا قبل أن يبنيه GitHub.

## ماذا يفعل التطبيق؟

- يقيس زمن استجابة طلبين عبر HTTPS إلى Cloudflare DNS-over-HTTPS وGoogle DNS-over-HTTPS.
- يوفر فحصًا فوريًا، ومراقبة متكررة كل 8 ثوانٍ، واختبار استقرار لمدة 60 ثانية وسجلًا لآخر العينات.
- يفتح صفحة الراوتر المحلية في متصفح الهاتف. يجب أن يكون الهاتف متصلًا بشبكة Wi-Fi الخاصة بالراوتر لكي يعمل العنوان `http://192.168.0.1/`.
- يقدّم خطوات فحص إرشادية لخيارات DNS Check وKeep Alive وAPN بحسب ما يتوفر في إصدار الراوتر.
- لا يحفظ اسم المستخدم أو كلمة مرور الراوتر، ولا يضمّن بيانات الدخول في ملفات التطبيق.

## كيف يبني GitHub ملف APK تلقائيًا؟

الملف `.github/workflows/build-apk.yml` يبدأ تلقائيًا عند كل دفع إلى الفرع `main`. ويمكن تشغيله يدويًا من تبويب **Actions** واختيار **Build and publish NetPulse Android APK** ثم **Run workflow**.

عند نجاح البناء، ينشر GitHub الملف `NetPulse.apk` في صفحة **Releases** ويرفع نسخة أيضًا في **Actions → Artifacts**. افتح صفحة Releases ثم نزّل `NetPulse.apk` على هاتف Android، وافتح الملف، ووافق على التثبيت من المصدر الذي استخدمته عند الطلب.

## التشغيل محليًا

المتطلبات: Node.js 22، Java 21، وAndroid SDK أو Android Studio.

```bash
npm install
npm run dev
```

لبناء Android محليًا:

```bash
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

ملف الاختبار الناتج محليًا يكون في `android/app/build/outputs/apk/debug/app-debug.apk`.

## حدود مهمة

- الفحوصات زمن طلبات HTTPS إلى خوادم DNS؛ ليست ICMP Ping مباشرًا للراوتر ولا قياسًا لقوة إشارة المودم.
- التطبيق لا يستطيع ضمان سرعة أعلى أو منع الانقطاع نهائيًا أو تجاوز ضعف تغطية 3G.
- لا يعيد تشغيل اتصال الراوتر تلقائيًا في هذه النسخة. التحكم بذلك يحتاج واجهة موثقة ومدعومة من إصدار الجهاز وبرنامجه الثابت.
- الـAPK الحالي من نوع Debug للتجربة والتثبيت المباشر وليس للنشر على Google Play. GitHub runner يولّد مفتاح debug مؤقتًا، لذلك قد تحتاج إلى حذف النسخة القديمة من الهاتف قبل تثبيت APK أحدث. يمكن لاحقًا إعداد توقيع ثابت عبر GitHub Actions Secrets.
